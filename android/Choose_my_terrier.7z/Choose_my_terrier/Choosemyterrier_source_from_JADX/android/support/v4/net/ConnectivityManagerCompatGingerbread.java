package android.support.v4.net;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.widget.CursorAdapter;

class ConnectivityManagerCompatGingerbread {
    ConnectivityManagerCompatGingerbread() {
    }

    public static boolean isActiveNetworkMetered(ConnectivityManager cm) {
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null) {
            return true;
        }
        switch (info.getType()) {
            case ViewPager.SCROLL_STATE_IDLE /*0*/:
            case CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER /*2*/:
            case FragmentManagerImpl.ANIM_STYLE_CLOSE_ENTER /*3*/:
            case AccessibilityNodeInfoCompat.MOVEMENT_GRANULARITY_LINE /*4*/:
            case MotionEventCompat.ACTION_POINTER_DOWN /*5*/:
            case MotionEventCompat.ACTION_POINTER_UP /*6*/:
                return true;
            case CursorAdapter.FLAG_AUTO_REQUERY /*1*/:
                return false;
            default:
                return true;
        }
    }
}
