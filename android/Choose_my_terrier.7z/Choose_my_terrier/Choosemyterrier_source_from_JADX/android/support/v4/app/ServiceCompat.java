package android.support.v4.app;

public class ServiceCompat {
    public static final int START_STICKY = 1;

    private ServiceCompat() {
    }
}
