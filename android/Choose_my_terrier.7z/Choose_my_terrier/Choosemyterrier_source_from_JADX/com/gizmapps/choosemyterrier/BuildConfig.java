package com.gizmapps.choosemyterrier;

public final class BuildConfig {
    public static final boolean DEBUG = false;
}
