package com.gizmapps.choosemyterrier;

/* renamed from: com.gizmapps.choosemyterrier.R */
public final class C0092R {

    /* renamed from: com.gizmapps.choosemyterrier.R.attr */
    public static final class attr {
    }

    /* renamed from: com.gizmapps.choosemyterrier.R.dimen */
    public static final class dimen {
        public static final int padding_large = 2131034114;
        public static final int padding_medium = 2131034113;
        public static final int padding_small = 2131034112;
    }

    /* renamed from: com.gizmapps.choosemyterrier.R.drawable */
    public static final class drawable {
        public static final int agility = 2130837504;
        public static final int airdale = 2130837505;
        public static final int airedale = 2130837506;
        public static final int americanstaffordshire = 2130837507;
        public static final int amstaf = 2130837508;
        public static final int austerrier = 2130837509;
        public static final int australian = 2130837510;
        public static final int bedlington = 2130837511;
        public static final int bedlingtonr = 2130837512;
        public static final int border = 2130837513;
        public static final int borderr = 2130837514;
        public static final int bullterrier = 2130837515;
        public static final int bullterrierr = 2130837516;
        public static final int cairn = 2130837517;
        public static final int cairnr = 2130837518;
        public static final int dandiedinmont = 2130837519;
        public static final int dandierr = 2130837520;
        public static final int dogbutton = 2130837521;
        public static final int englishstaffordshirebull = 2130837522;
        public static final int goodkids = 2130837523;
        public static final int guard = 2130837524;
        public static final int ic_action_search = 2130837525;
        public static final int ic_launcher = 2130837526;
        public static final int info = 2130837527;
        public static final int intro = 2130837528;
        public static final int irish = 2130837529;
        public static final int irishr = 2130837530;
        public static final int jackr = 2130837531;
        public static final int jackrussell = 2130837532;
        public static final int kentriki = 2130837533;
        public static final int kentriki2 = 2130837534;
        public static final int kentriki3 = 2130837535;
        public static final int kerryblue = 2130837536;
        public static final int kerryr = 2130837537;
        public static final int lakeland = 2130837538;
        public static final int laker = 2130837539;
        public static final int manchester = 2130837540;
        public static final int manr = 2130837541;
        public static final int mbr = 2130837542;
        public static final int miniaturebull = 2130837543;
        public static final int miniatureschnauzer = 2130837544;
        public static final int msnazr = 2130837545;
        public static final int norfolk = 2130837546;
        public static final int norfolkr = 2130837547;
        public static final int norr = 2130837548;
        public static final int norwich = 2130837549;
        public static final int scotishr = 2130837550;
        public static final int scottish = 2130837551;
        public static final int sealyham = 2130837552;
        public static final int sear = 2130837553;
        public static final int sfoxr = 2130837554;
        public static final int shedding = 2130837555;
        public static final int size = 2130837556;
        public static final int skye = 2130837557;
        public static final int skyerr = 2130837558;
        public static final int smoothfox = 2130837559;
        public static final int softcoatedwheaten = 2130837560;
        public static final int staffier = 2130837561;
        public static final int training = 2130837562;
        public static final int welsh = 2130837563;
        public static final int welshr = 2130837564;
        public static final int westhighlandwhite = 2130837565;
        public static final int westr = 2130837566;
        public static final int wheatenr = 2130837567;
        public static final int wirefox = 2130837568;
        public static final int wirer = 2130837569;
    }

    /* renamed from: com.gizmapps.choosemyterrier.R.id */
    public static final class id {
        public static final int TextView01 = 2131296290;
        public static final int air1 = 2131296262;
        public static final int air2 = 2131296266;
        public static final int air3 = 2131296263;
        public static final int air4 = 2131296265;
        public static final int air5 = 2131296267;
        public static final int air6 = 2131296264;
        public static final int airinfo = 2131296259;
        public static final int airquiz = 2131296260;
        public static final int amstafinfo = 2131296280;
        public static final int amstafquiz = 2131296281;
        public static final int ausquiz = 2131296283;
        public static final int austinfo = 2131296282;
        public static final int bedinfo = 2131296284;
        public static final int bedquiz = 2131296285;
        public static final int borinfo = 2131296286;
        public static final int borquiz = 2131296287;
        public static final int btnres = 2131296269;
        public static final int btnyes1 = 2131296273;
        public static final int btnyes2 = 2131296278;
        public static final int btnyes3 = 2131296272;
        public static final int btnyes4 = 2131296271;
        public static final int btnyes5 = 2131296270;
        public static final int bullterinfo = 2131296288;
        public static final int bullterquiz = 2131296289;
        public static final int cairninfo = 2131296292;
        public static final int cairnquiz = 2131296293;
        public static final int dadinfo = 2131296294;
        public static final int dadquiz = 2131296295;
        public static final int ibtn1 = 2131296324;
        public static final int ibtn10 = 2131296333;
        public static final int ibtn11 = 2131296334;
        public static final int ibtn12 = 2131296335;
        public static final int ibtn13 = 2131296336;
        public static final int ibtn14 = 2131296337;
        public static final int ibtn15 = 2131296338;
        public static final int ibtn16 = 2131296339;
        public static final int ibtn17 = 2131296340;
        public static final int ibtn18 = 2131296341;
        public static final int ibtn19 = 2131296342;
        public static final int ibtn2 = 2131296325;
        public static final int ibtn20 = 2131296343;
        public static final int ibtn21 = 2131296344;
        public static final int ibtn22 = 2131296345;
        public static final int ibtn23 = 2131296346;
        public static final int ibtn24 = 2131296347;
        public static final int ibtn25 = 2131296348;
        public static final int ibtn26 = 2131296349;
        public static final int ibtn3 = 2131296326;
        public static final int ibtn4 = 2131296327;
        public static final int ibtn5 = 2131296328;
        public static final int ibtn6 = 2131296329;
        public static final int ibtn7 = 2131296330;
        public static final int ibtn8 = 2131296331;
        public static final int ibtn9 = 2131296332;
        public static final int imageView1 = 2131296261;
        public static final int irishinfo = 2131296296;
        public static final int irishquiz = 2131296297;
        public static final int jackinfo = 2131296298;
        public static final int jackquiz = 2131296299;
        public static final int kerryinfo = 2131296300;
        public static final int kerryquiz = 2131296301;
        public static final int lakinfo = 2131296302;
        public static final int lakquiz = 2131296303;
        public static final int maninfo = 2131296304;
        public static final int manquiz = 2131296305;
        public static final int mbullinfo = 2131296306;
        public static final int mbullquiz = 2131296307;
        public static final int menuSweet = 2131296360;
        public static final int menuToast = 2131296361;
        public static final int menu_settings = 2131296359;
        public static final int msnazinfo = 2131296308;
        public static final int msnazquiz = 2131296309;
        public static final int norfinfo = 2131296312;
        public static final int norfquiz = 2131296313;
        public static final int norinfo = 2131296310;
        public static final int norquiz = 2131296311;
        public static final int resulttxt = 2131296268;
        public static final int scinfo = 2131296314;
        public static final int scquiz = 2131296315;
        public static final int seainfo = 2131296316;
        public static final int selis1 = 2131296258;
        public static final int selis2 = 2131296257;
        public static final int sfoxinfo = 2131296318;
        public static final int sfoxquiz = 2131296319;
        public static final int skyinfo = 2131296320;
        public static final int skyquiz = 2131296321;
        public static final int squiz = 2131296317;
        public static final int staffieinfo = 2131296322;
        public static final int staffiequiz = 2131296323;
        public static final int textView1 = 2131296256;
        public static final int textView2 = 2131296275;
        public static final int textView3 = 2131296274;
        public static final int textView4 = 2131296279;
        public static final int textView5 = 2131296277;
        public static final int textView6 = 2131296276;
        public static final int textView7 = 2131296291;
        public static final int txtv1 = 2131296350;
        public static final int welshinfo = 2131296351;
        public static final int welshquiz = 2131296352;
        public static final int westhinfo = 2131296353;
        public static final int westhquiz = 2131296354;
        public static final int wheateninfo = 2131296355;
        public static final int wheatenquiz = 2131296356;
        public static final int wirefinfo = 2131296357;
        public static final int wirefquiz = 2131296358;
    }

    /* renamed from: com.gizmapps.choosemyterrier.R.layout */
    public static final class layout {
        public static final int activity_main = 2130903040;
        public static final int airadale = 2130903041;
        public static final int airquiz = 2130903042;
        public static final int americanstaff = 2130903043;
        public static final int amstaffquiz = 2130903044;
        public static final int ausquiz = 2130903045;
        public static final int austerrier = 2130903046;
        public static final int bedlington = 2130903047;
        public static final int bedquiz = 2130903048;
        public static final int border = 2130903049;
        public static final int borderquiz = 2130903050;
        public static final int bullter = 2130903051;
        public static final int bullterquiz = 2130903052;
        public static final int cairn = 2130903053;
        public static final int cairnquiz = 2130903054;
        public static final int dadie = 2130903055;
        public static final int dadiequiz = 2130903056;
        public static final int info = 2130903057;
        public static final int irish = 2130903058;
        public static final int irishquiz = 2130903059;
        public static final int jack = 2130903060;
        public static final int jackquiz = 2130903061;
        public static final int kerry = 2130903062;
        public static final int kerryquiz = 2130903063;
        public static final int lake = 2130903064;
        public static final int lakequiz = 2130903065;
        public static final int man = 2130903066;
        public static final int manquiz = 2130903067;
        public static final int mbull = 2130903068;
        public static final int mbullquiz = 2130903069;
        public static final int msnaz = 2130903070;
        public static final int msnazquiz = 2130903071;
        public static final int nor = 2130903072;
        public static final int norf = 2130903073;
        public static final int norfquiz = 2130903074;
        public static final int norquiz = 2130903075;
        public static final int scotish = 2130903076;
        public static final int scotishquiz = 2130903077;
        public static final int sealyham = 2130903078;
        public static final int seaquiz = 2130903079;
        public static final int sfox = 2130903080;
        public static final int sfoxquiz = 2130903081;
        public static final int skye = 2130903082;
        public static final int skyequiz = 2130903083;
        public static final int splash = 2130903084;
        public static final int staffie = 2130903085;
        public static final int staffiequiz = 2130903086;
        public static final int terriertypes = 2130903087;
        public static final int welsh = 2130903088;
        public static final int welshquiz = 2130903089;
        public static final int westh = 2130903090;
        public static final int westhquiz = 2130903091;
        public static final int wheaten = 2130903092;
        public static final int wheatenquiz = 2130903093;
        public static final int wirefox = 2130903094;
        public static final int wirefoxquiz = 2130903095;
    }

    /* renamed from: com.gizmapps.choosemyterrier.R.menu */
    public static final class menu {
        public static final int activity_main = 2131230720;
        public static final int main_menu = 2131230721;
    }

    /* renamed from: com.gizmapps.choosemyterrier.R.raw */
    public static final class raw {
        public static final int bark = 2130968576;
        public static final int button_click = 2130968577;
    }

    /* renamed from: com.gizmapps.choosemyterrier.R.string */
    public static final class string {
        public static final int app_name = 2131099648;
        public static final int koumpi1 = 2131099651;
        public static final int menu_settings = 2131099649;
        public static final int title_activity_main = 2131099650;
    }

    /* renamed from: com.gizmapps.choosemyterrier.R.style */
    public static final class style {
        public static final int AppTheme = 2131165184;
    }
}
