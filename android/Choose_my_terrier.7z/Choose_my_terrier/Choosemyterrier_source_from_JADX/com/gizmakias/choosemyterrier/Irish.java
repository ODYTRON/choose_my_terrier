package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Irish extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Irish.1 */
    class C00441 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00441(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Irish_terrier");
        }

        private void goToUrl(String url) {
            Irish.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Irish.2 */
    class C00452 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00452(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Irish.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.IRISHQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.irish);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button irishquiz = (Button) findViewById(C0092R.id.irishquiz);
        ((Button) findViewById(C0092R.id.irishinfo)).setOnClickListener(new C00441(buttonSound));
        irishquiz.setOnClickListener(new C00452(buttonSound));
    }
}
