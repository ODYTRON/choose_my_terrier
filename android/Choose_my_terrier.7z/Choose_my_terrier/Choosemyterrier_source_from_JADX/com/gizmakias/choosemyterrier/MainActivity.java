package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import com.gizmapps.choosemyterrier.C0092R;

public class MainActivity extends Activity {
    MediaPlayer logoMusic;

    /* renamed from: com.gizmakias.choosemyterrier.MainActivity.1 */
    class C00521 extends Thread {
        C00521() {
        }

        public void run() {
            try {
                C00521.sleep(3000);
                MainActivity.this.startActivity(new Intent("com.gizmakias.choosemyterrier.MENU"));
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                MainActivity.this.finish();
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.splash);
        MediaPlayer.create(this, C0092R.raw.bark).start();
        new C00521().start();
    }

    protected void onPause() {
        super.onPause();
    }
}
