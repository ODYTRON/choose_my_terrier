package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Staffie extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Staffie.1 */
    class C00731 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00731(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Staffordshire_Bull_Terrier");
        }

        private void goToUrl(String url) {
            Staffie.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Staffie.2 */
    class C00742 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00742(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Staffie.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.STAFFIEQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.staffie);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button staffiequiz = (Button) findViewById(C0092R.id.staffiequiz);
        ((Button) findViewById(C0092R.id.staffieinfo)).setOnClickListener(new C00731(buttonSound));
        staffiequiz.setOnClickListener(new C00742(buttonSound));
    }
}
