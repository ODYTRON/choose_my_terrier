package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Menu extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Menu.1 */
    class C00571 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00571(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Menu.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.TERRIERTYPES")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Menu.2 */
    class C00582 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00582(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Menu.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.INFO")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.activity_main);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button tut2 = (Button) findViewById(C0092R.id.selis2);
        ((Button) findViewById(C0092R.id.selis1)).setOnClickListener(new C00571(buttonSound));
        tut2.setOnClickListener(new C00582(buttonSound));
    }

    protected void onPause() {
        super.onPause();
    }
}
