package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Kerry extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Kerry.1 */
    class C00481 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00481(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Kerry_blue_terrier");
        }

        private void goToUrl(String url) {
            Kerry.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Kerry.2 */
    class C00492 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00492(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Kerry.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.KERRYQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.kerry);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button kerryquiz = (Button) findViewById(C0092R.id.kerryquiz);
        ((Button) findViewById(C0092R.id.kerryinfo)).setOnClickListener(new C00481(buttonSound));
        kerryquiz.setOnClickListener(new C00492(buttonSound));
    }
}
