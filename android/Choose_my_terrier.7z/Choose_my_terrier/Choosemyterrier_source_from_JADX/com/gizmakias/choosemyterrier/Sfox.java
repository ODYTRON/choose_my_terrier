package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Sfox extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Sfox.1 */
    class C00691 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00691(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Smooth_fox_terrier");
        }

        private void goToUrl(String url) {
            Sfox.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Sfox.2 */
    class C00702 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00702(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Sfox.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.SFOXQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.sfox);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button sfoxquiz = (Button) findViewById(C0092R.id.sfoxquiz);
        ((Button) findViewById(C0092R.id.sfoxinfo)).setOnClickListener(new C00691(buttonSound));
        sfoxquiz.setOnClickListener(new C00702(buttonSound));
    }
}
