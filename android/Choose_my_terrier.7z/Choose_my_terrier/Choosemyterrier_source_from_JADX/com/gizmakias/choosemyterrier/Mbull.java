package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Mbull extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Mbull.1 */
    class C00551 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00551(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Miniature_bull_terrier");
        }

        private void goToUrl(String url) {
            Mbull.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Mbull.2 */
    class C00562 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00562(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Mbull.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.MBULLQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.mbull);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button mbullquiz = (Button) findViewById(C0092R.id.mbullquiz);
        ((Button) findViewById(C0092R.id.mbullinfo)).setOnClickListener(new C00551(buttonSound));
        mbullquiz.setOnClickListener(new C00562(buttonSound));
    }
}
