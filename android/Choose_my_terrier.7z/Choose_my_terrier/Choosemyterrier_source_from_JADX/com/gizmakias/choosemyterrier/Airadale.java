package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Airadale extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Airadale.1 */
    class C00281 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00281(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Airedale_terrier");
        }

        private void goToUrl(String url) {
            Airadale.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Airadale.2 */
    class C00292 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00292(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Airadale.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.AIRQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.airadale);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button airquiz = (Button) findViewById(C0092R.id.airquiz);
        ((Button) findViewById(C0092R.id.airinfo)).setOnClickListener(new C00281(buttonSound));
        airquiz.setOnClickListener(new C00292(buttonSound));
    }
}
