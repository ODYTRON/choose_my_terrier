package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import com.gizmapps.choosemyterrier.C0092R;

public class Borderquiz extends Activity implements OnClickListener {
    private Button b1;
    private Button b3;
    private Button b5;
    private Button b7;
    private Button b9;
    int counter;
    private Button res;
    EditText shw;
    String strcounter;
    int sum;

    public Borderquiz() {
        this.counter = 0;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.borderquiz);
        this.b1 = (Button) findViewById(C0092R.id.btnyes1);
        this.b3 = (Button) findViewById(C0092R.id.btnyes2);
        this.b5 = (Button) findViewById(C0092R.id.btnyes3);
        this.b7 = (Button) findViewById(C0092R.id.btnyes4);
        this.b9 = (Button) findViewById(C0092R.id.btnyes5);
        this.res = (Button) findViewById(C0092R.id.btnres);
        this.shw = (EditText) findViewById(C0092R.id.resulttxt);
        this.b1.setOnClickListener(this);
        this.b3.setOnClickListener(this);
        this.b5.setOnClickListener(this);
        this.b7.setOnClickListener(this);
        this.b9.setOnClickListener(this);
        this.res.setOnClickListener(this);
    }

    public void onClick(View v) {
        if (v.getId() == C0092R.id.btnyes1) {
            ((Button) findViewById(C0092R.id.btnyes1)).setEnabled(false);
        }
        if (v == this.b1) {
            this.counter++;
            this.strcounter = Integer.toString(this.counter);
            this.shw.setText(this.strcounter);
        }
        if (v.getId() == C0092R.id.btnyes2) {
            ((Button) findViewById(C0092R.id.btnyes2)).setEnabled(false);
        }
        if (v == this.b3) {
            this.counter++;
            this.strcounter = Integer.toString(this.counter);
            this.shw.setText(this.strcounter);
        }
        if (v.getId() == C0092R.id.btnyes3) {
            ((Button) findViewById(C0092R.id.btnyes3)).setEnabled(false);
        }
        if (v == this.b5) {
            this.counter++;
            this.strcounter = Integer.toString(this.counter);
            this.shw.setText(this.strcounter);
        }
        if (v.getId() == C0092R.id.btnyes4) {
            ((Button) findViewById(C0092R.id.btnyes4)).setEnabled(false);
        }
        if (v == this.b7) {
            this.counter++;
            this.strcounter = Integer.toString(this.counter);
            this.shw.setText(this.strcounter);
        }
        if (v.getId() == C0092R.id.btnyes5) {
            ((Button) findViewById(C0092R.id.btnyes5)).setEnabled(false);
        }
        if (v == this.b9) {
            this.counter++;
            this.strcounter = Integer.toString(this.counter);
            this.shw.setText(this.strcounter);
        }
        if (v.getId() == C0092R.id.btnres) {
            ((Button) findViewById(C0092R.id.btnres)).setEnabled(true);
        }
        if (v == this.res) {
            this.strcounter = Integer.toString(this.counter);
        }
        if (v.getId() == C0092R.id.btnres) {
            this.b1.setEnabled(false);
            this.b3.setEnabled(false);
            this.b5.setEnabled(false);
            this.b7.setEnabled(false);
            this.b9.setEnabled(false);
            if (this.strcounter == "0") {
                this.shw.setText("Take the quiz again and answer at least one question.");
            }
            if (this.strcounter.equals("1")) {
                this.shw.setText("Keep away from Border Terrier. ");
            }
            if (this.strcounter.equals("2")) {
                this.shw.setText("Border Terrier is not a good choice for you.");
            }
            if (this.strcounter.equals("3")) {
                this.shw.setText("Border Terrier is ok for you.");
            }
            if (this.strcounter.equals("4")) {
                this.shw.setText("Border Terrier is the best choice for you.");
            }
            if (this.strcounter.equals("5")) {
                this.shw.setText("Border Terrier is the best choice for you.");
            }
            this.b1.setEnabled(false);
            this.b3.setEnabled(false);
            this.b5.setEnabled(false);
            this.b7.setEnabled(false);
            this.b9.setEnabled(false);
        }
    }
}
