package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Border extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Border.1 */
    class C00361 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00361(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Border_Terrier");
        }

        private void goToUrl(String url) {
            Border.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Border.2 */
    class C00372 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00372(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Border.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.BORDERQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.border);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button bordquiz = (Button) findViewById(C0092R.id.borquiz);
        ((Button) findViewById(C0092R.id.borinfo)).setOnClickListener(new C00361(buttonSound));
        bordquiz.setOnClickListener(new C00372(buttonSound));
    }
}
