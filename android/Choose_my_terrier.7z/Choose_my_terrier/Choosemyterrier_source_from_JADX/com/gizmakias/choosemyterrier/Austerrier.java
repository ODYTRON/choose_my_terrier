package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Austerrier extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Austerrier.1 */
    class C00321 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00321(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Australian_Terrier");
        }

        private void goToUrl(String url) {
            Austerrier.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Austerrier.2 */
    class C00332 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00332(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Austerrier.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.AUSQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.austerrier);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button austerquiz = (Button) findViewById(C0092R.id.ausquiz);
        ((Button) findViewById(C0092R.id.austinfo)).setOnClickListener(new C00321(buttonSound));
        austerquiz.setOnClickListener(new C00332(buttonSound));
    }
}
