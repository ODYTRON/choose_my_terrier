package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Man extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Man.1 */
    class C00531 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00531(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Manchester_terrier");
        }

        private void goToUrl(String url) {
            Man.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Man.2 */
    class C00542 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00542(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Man.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.MANQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.man);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button manquiz = (Button) findViewById(C0092R.id.manquiz);
        ((Button) findViewById(C0092R.id.maninfo)).setOnClickListener(new C00531(buttonSound));
        manquiz.setOnClickListener(new C00542(buttonSound));
    }
}
