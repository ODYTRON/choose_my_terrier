package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Westh extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Westh.1 */
    class C00861 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00861(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/West_Highland_Terrier");
        }

        private void goToUrl(String url) {
            Westh.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Westh.2 */
    class C00872 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00872(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Westh.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.WESTHQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.westh);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button westhquiz = (Button) findViewById(C0092R.id.westhquiz);
        ((Button) findViewById(C0092R.id.westhinfo)).setOnClickListener(new C00861(buttonSound));
        westhquiz.setOnClickListener(new C00872(buttonSound));
    }
}
