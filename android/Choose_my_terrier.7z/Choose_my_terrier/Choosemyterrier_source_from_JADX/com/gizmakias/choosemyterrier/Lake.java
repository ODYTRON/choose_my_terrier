package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Lake extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Lake.1 */
    class C00501 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00501(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Lakeland_Terrier");
        }

        private void goToUrl(String url) {
            Lake.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Lake.2 */
    class C00512 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00512(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Lake.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.LAKEQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.lake);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button lakquiz = (Button) findViewById(C0092R.id.lakquiz);
        ((Button) findViewById(C0092R.id.lakinfo)).setOnClickListener(new C00501(buttonSound));
        lakquiz.setOnClickListener(new C00512(buttonSound));
    }
}
