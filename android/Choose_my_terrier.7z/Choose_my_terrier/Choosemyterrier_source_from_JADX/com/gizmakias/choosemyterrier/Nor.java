package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Nor extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Nor.1 */
    class C00611 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00611(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Norwich_terrier");
        }

        private void goToUrl(String url) {
            Nor.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Nor.2 */
    class C00622 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00622(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Nor.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.NORQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.nor);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button norquiz = (Button) findViewById(C0092R.id.norquiz);
        ((Button) findViewById(C0092R.id.norinfo)).setOnClickListener(new C00611(buttonSound));
        norquiz.setOnClickListener(new C00622(buttonSound));
    }
}
