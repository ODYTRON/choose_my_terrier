package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.os.Bundle;
import com.gizmapps.choosemyterrier.C0092R;

public class Info extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.info);
    }
}
