package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Jack extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Jack.1 */
    class C00461 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00461(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Jack_Russell_Terrier");
        }

        private void goToUrl(String url) {
            Jack.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Jack.2 */
    class C00472 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00472(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Jack.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.JACKQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.jack);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button jackquiz = (Button) findViewById(C0092R.id.jackquiz);
        ((Button) findViewById(C0092R.id.jackinfo)).setOnClickListener(new C00461(buttonSound));
        jackquiz.setOnClickListener(new C00472(buttonSound));
    }
}
