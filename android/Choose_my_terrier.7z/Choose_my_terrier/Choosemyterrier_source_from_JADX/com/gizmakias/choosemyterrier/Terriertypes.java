package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Terriertypes extends Activity implements OnClickListener {
    Button airdale;
    Button americanst;
    Button austerrier;
    Button bedterrier;
    Button bordterrier;
    Button bullterrier;
    Button dadieterrier;
    Button irishterrier;
    Button jackterrier;
    Button kerryterrier;
    Button manterrier;
    Button msnazterrier;
    Button norfterrier;
    Button norterrier;
    Button scotishterrier;
    Button sealyhamterrier;
    Button sfoxterrier;
    Button skyeterrier;
    Button staffieterrier;
    Button welshterrier;
    Button westhterrier;
    Button wheatenterrier;
    Button wirefoxterrier;

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.10 */
    class AnonymousClass10 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass10(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.SKYE")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.11 */
    class AnonymousClass11 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass11(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.SFOX")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.12 */
    class AnonymousClass12 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass12(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.WHEATEN")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.13 */
    class AnonymousClass13 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass13(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.WELSH")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.14 */
    class AnonymousClass14 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass14(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.WESTH")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.15 */
    class AnonymousClass15 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass15(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.KERRY")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.16 */
    class AnonymousClass16 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass16(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.IRISH")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.17 */
    class AnonymousClass17 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass17(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.JACK")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.18 */
    class AnonymousClass18 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass18(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.CAIRNTERRIER")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.19 */
    class AnonymousClass19 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass19(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.STAFFIE")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.1 */
    class C00751 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00751(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.AIRADALE")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.20 */
    class AnonymousClass20 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass20(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.AUSTERRIER")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.21 */
    class AnonymousClass21 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass21(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.DADIE")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.22 */
    class AnonymousClass22 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass22(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.BORDER")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.23 */
    class AnonymousClass23 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass23(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.BULLTER")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.24 */
    class AnonymousClass24 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass24(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.WIREFOX")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.25 */
    class AnonymousClass25 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass25(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.BEDLINGTON")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.26 */
    class AnonymousClass26 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        AnonymousClass26(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.AMERICANSTAFF")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.2 */
    class C00762 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00762(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.MAN")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.3 */
    class C00773 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00773(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.LAKE")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.4 */
    class C00784 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00784(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.MBULL")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.5 */
    class C00795 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00795(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.MSNAZ")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.6 */
    class C00806 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00806(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.NORF")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.7 */
    class C00817 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00817(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.NOR")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.8 */
    class C00828 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00828(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.SCOTISH")));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Terriertypes.9 */
    class C00839 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00839(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Terriertypes.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.SEALYHAM")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.terriertypes);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button americanst = (Button) findViewById(C0092R.id.ibtn2);
        Button austerrier = (Button) findViewById(C0092R.id.ibtn3);
        Button bedterrier = (Button) findViewById(C0092R.id.ibtn4);
        Button bordterrier = (Button) findViewById(C0092R.id.ibtn5);
        Button bullterrier = (Button) findViewById(C0092R.id.ibtn6);
        Button cairnterrier = (Button) findViewById(C0092R.id.ibtn7);
        Button dadieterrier = (Button) findViewById(C0092R.id.ibtn8);
        Button staffieterrier = (Button) findViewById(C0092R.id.ibtn9);
        Button irishterrier = (Button) findViewById(C0092R.id.ibtn10);
        Button jackterrier = (Button) findViewById(C0092R.id.ibtn11);
        Button kerryterrier = (Button) findViewById(C0092R.id.ibtn12);
        Button laketerrier = (Button) findViewById(C0092R.id.ibtn13);
        Button manterrier = (Button) findViewById(C0092R.id.ibtn14);
        Button mbullterrier = (Button) findViewById(C0092R.id.ibtn15);
        Button msnazterrier = (Button) findViewById(C0092R.id.ibtn16);
        Button norfterrier = (Button) findViewById(C0092R.id.ibtn17);
        Button norterrier = (Button) findViewById(C0092R.id.ibtn18);
        Button scotishterrier = (Button) findViewById(C0092R.id.ibtn19);
        Button sealyhamterrier = (Button) findViewById(C0092R.id.ibtn20);
        Button skyeterrier = (Button) findViewById(C0092R.id.ibtn21);
        Button sfoxterrier = (Button) findViewById(C0092R.id.ibtn22);
        Button wheatenterrier = (Button) findViewById(C0092R.id.ibtn23);
        Button welshterrier = (Button) findViewById(C0092R.id.ibtn24);
        Button westhterrier = (Button) findViewById(C0092R.id.ibtn25);
        Button wirefoxterrier = (Button) findViewById(C0092R.id.ibtn26);
        ((Button) findViewById(C0092R.id.ibtn1)).setOnClickListener(new C00751(buttonSound));
        manterrier.setOnClickListener(new C00762(buttonSound));
        laketerrier.setOnClickListener(new C00773(buttonSound));
        mbullterrier.setOnClickListener(new C00784(buttonSound));
        msnazterrier.setOnClickListener(new C00795(buttonSound));
        norfterrier.setOnClickListener(new C00806(buttonSound));
        norterrier.setOnClickListener(new C00817(buttonSound));
        scotishterrier.setOnClickListener(new C00828(buttonSound));
        sealyhamterrier.setOnClickListener(new C00839(buttonSound));
        skyeterrier.setOnClickListener(new AnonymousClass10(buttonSound));
        sfoxterrier.setOnClickListener(new AnonymousClass11(buttonSound));
        wheatenterrier.setOnClickListener(new AnonymousClass12(buttonSound));
        welshterrier.setOnClickListener(new AnonymousClass13(buttonSound));
        westhterrier.setOnClickListener(new AnonymousClass14(buttonSound));
        kerryterrier.setOnClickListener(new AnonymousClass15(buttonSound));
        irishterrier.setOnClickListener(new AnonymousClass16(buttonSound));
        jackterrier.setOnClickListener(new AnonymousClass17(buttonSound));
        cairnterrier.setOnClickListener(new AnonymousClass18(buttonSound));
        staffieterrier.setOnClickListener(new AnonymousClass19(buttonSound));
        austerrier.setOnClickListener(new AnonymousClass20(buttonSound));
        dadieterrier.setOnClickListener(new AnonymousClass21(buttonSound));
        bordterrier.setOnClickListener(new AnonymousClass22(buttonSound));
        bullterrier.setOnClickListener(new AnonymousClass23(buttonSound));
        wirefoxterrier.setOnClickListener(new AnonymousClass24(buttonSound));
        bedterrier.setOnClickListener(new AnonymousClass25(buttonSound));
        americanst.setOnClickListener(new AnonymousClass26(buttonSound));
    }

    public void onClick(View v) {
    }
}
