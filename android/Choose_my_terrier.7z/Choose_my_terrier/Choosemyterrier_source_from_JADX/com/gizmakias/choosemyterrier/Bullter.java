package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Bullter extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Bullter.1 */
    class C00381 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00381(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Bull_terrier");
        }

        private void goToUrl(String url) {
            Bullter.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Bullter.2 */
    class C00392 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00392(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Bullter.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.BULLTERQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.bullter);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button bullterquiz = (Button) findViewById(C0092R.id.bullterquiz);
        ((Button) findViewById(C0092R.id.bullterinfo)).setOnClickListener(new C00381(buttonSound));
        bullterquiz.setOnClickListener(new C00392(buttonSound));
    }
}
