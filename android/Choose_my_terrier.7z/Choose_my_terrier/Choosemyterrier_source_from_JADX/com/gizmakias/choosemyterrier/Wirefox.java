package com.gizmakias.choosemyterrier;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.gizmapps.choosemyterrier.C0092R;

public class Wirefox extends Activity {

    /* renamed from: com.gizmakias.choosemyterrier.Wirefox.1 */
    class C00901 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00901(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            goToUrl("http://en.wikipedia.org/wiki/Wire_fox_terrier");
        }

        private void goToUrl(String url) {
            Wirefox.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }
    }

    /* renamed from: com.gizmakias.choosemyterrier.Wirefox.2 */
    class C00912 implements OnClickListener {
        private final /* synthetic */ MediaPlayer val$buttonSound;

        C00912(MediaPlayer mediaPlayer) {
            this.val$buttonSound = mediaPlayer;
        }

        public void onClick(View v) {
            this.val$buttonSound.start();
            Wirefox.this.startActivity(new Intent(new Intent("com.gizmakias.choosemyterrier.WIREFOXQUIZ")));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0092R.layout.wirefox);
        MediaPlayer buttonSound = MediaPlayer.create(this, C0092R.raw.button_click);
        Button wirefquiz = (Button) findViewById(C0092R.id.wirefquiz);
        ((Button) findViewById(C0092R.id.wirefinfo)).setOnClickListener(new C00901(buttonSound));
        wirefquiz.setOnClickListener(new C00912(buttonSound));
    }
}
